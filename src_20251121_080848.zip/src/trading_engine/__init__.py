"""Package initializer for trading_engine."""
