"""Package initializer for evaluation."""
