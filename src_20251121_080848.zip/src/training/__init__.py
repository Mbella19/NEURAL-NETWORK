"""Package initializer for training."""
